import LandingPage from "./components/Header";

function App() {
  return <div className=""></div>;
}

export default App;
