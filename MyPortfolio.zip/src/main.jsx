import React from "react";

import ReactDOM from "react-dom/client";
import App from "./App";
import { ChakraProvider } from "@chakra-ui/react";
import DashBoard from "./components/LandingSection";
import Navbar from "./components/Header";
import Projects from "./components/Projects";
import ContactMe from "./components/ContactMeSection";
import Footer from "./components/Footer";
import { AlertProvider } from "./context/alertContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  <ChakraProvider>
    <AlertProvider>
      <App />
      <Navbar />
      <DashBoard />
      <Projects />
      <ContactMe />
      <Footer />
    </AlertProvider>
  </ChakraProvider>
);
