import * as Yup from "yup";

export const basicSchema = Yup.object().shape({
  firstName: Yup.string().required("Required"),
  email: Yup.string().email("Invalid email address").required("Required"),
  type: Yup.string().required("required"),
  comment: Yup.string().min(25).required("Required"),
});
