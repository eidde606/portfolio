import {
  Box,
  FormControl,
  FormLabel,
  Input,
  Textarea,
  Button,
  VStack,
  Heading,
  FormErrorMessage,
  Select,
} from "@chakra-ui/react";
import { useFormik } from "formik";
import * as Yup from "yup";
import React, { useContext, useState } from "react";
import DashboardScreenSection from "./FullScreenSection";
import { basicSchema } from "../schemas";
import { useSubmit } from "../hooks/useSubmit.jsx";
import { useAlertContext } from "../context/alertContext";

const ContactMe = () => {
  const { submit } = useSubmit();
  const [response, setResponse] = useState(null);
  const {
    values,
    errors,
    touched,
    isSubmitting,
    handleSubmit,
    handleChange,
    resetForm,
  } = useFormik({
    initialValues: {
      email: "",
      firstName: "",
      type: "",
      comment: "",
    },
    validationSchema: basicSchema,
    onSubmit: async (values, actions) => {
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setResponse(response);
      actions.setSubmitting(false);

      if (response && response.type === "success") {
        onOpen("success", `Thanks for contacting me, ${values.firstName}!`);
        resetForm();
      } else if (response && response.type === "error") {
        onOpen("error", response.message);
      }
    },
  });

  const { onOpen } = useAlertContext();

  console.log(errors);
  return (
    <DashboardScreenSection
      isDarkBackground
      backgroundColor="#2A4365"
      py={16}
      spacing={8}
    >
      <VStack w="1024px" p={32} alignItems="flex-start">
        <Heading as="h1" id="contactme-section" color="yellow">
          Contact Me
        </Heading>
        <Box rounded="md" w="100%" p={6}>
          <form onSubmit={handleSubmit}>
            <VStack spacing={4}>
              <FormControl isInvalid={errors.firstName && touched.firstName}>
                <FormLabel htmlFor="firstName">Name</FormLabel>
                <Input
                  id="firstName"
                  name="firstName"
                  type="text"
                  value={values.firstName}
                  onChange={handleChange}
                />
                <FormErrorMessage>{errors.firstName}</FormErrorMessage>
              </FormControl>
              <FormControl isInvalid={errors.email && touched.email}>
                <FormLabel htmlFor="email">Email</FormLabel>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={values.email}
                  onChange={handleChange}
                />
                <FormErrorMessage>{errors.email}</FormErrorMessage>
              </FormControl>
              <FormControl>
                <FormLabel htmlFor="type">Type of enquiry</FormLabel>
                <Select
                  id="type"
                  name="type"
                  color="black"
                  value={values.type}
                  onChange={handleChange}
                  bg="white"
                >
                  <option value="hireMe">Freelance project proposal</option>
                  <option value="openSource">
                    Open source consultancy session
                  </option>
                  <option value="other">Other</option>
                </Select>
              </FormControl>
              <FormControl isInvalid={errors.comment && touched.comment}>
                <FormLabel htmlFor="comment">Your message</FormLabel>
                <Textarea
                  id="comment"
                  name="comment"
                  height={250}
                  value={values.comment}
                  onChange={handleChange}
                />
                <FormErrorMessage>{errors.comment}</FormErrorMessage>
              </FormControl>
              <Button
                disabled={isSubmitting}
                type="submit"
                colorScheme="yellow"
                width="full"
              >
                Submit
              </Button>
            </VStack>
          </form>
        </Box>
      </VStack>
    </DashboardScreenSection>
  );
};

export default ContactMe;
