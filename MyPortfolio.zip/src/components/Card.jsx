import { Divider, VStack } from "@chakra-ui/react";
import { HStack } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { Heading, Image, Text } from "@chakra-ui/react";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  return (
    <VStack
      borderWidth="0px"
      borderRadius="lg"
      overflow="hidden"
      boxShadow="md"
      maxW="sm"
      alignItems="flex-start"
      bgColor="white"
      p={2}
    >
      <Image src={imageSrc} alt={title} borderRadius="lg" width="384px" />
      <VStack alignItems="flex-start" spacing={2} bgColor="white">
        <Heading size="md" color="black">
          {title}
        </Heading>
        <Text color="gray">{description}</Text>
        <Divider />
        <HStack>
          <Text fontWeight="bold" color="black">
            Read more
          </Text>
          <FontAwesomeIcon icon={faArrowRight} color="black" />
        </HStack>
      </VStack>
    </VStack>
  );
};

export default Card;
