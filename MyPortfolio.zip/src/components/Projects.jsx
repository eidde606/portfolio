import { Box, Heading, Image } from "@chakra-ui/react";
import DashboardScreenSection from "./FullScreenSection";
import Card from "./Card";
import React from "react";
import photo1 from "../images/photo1.jpg";
import photo2 from "../images/photo2.jpg";
import photo3 from "../images/photo3.jpg";
import photo4 from "../images/photo4.jpg";

const projects = [
  {
    title: "React Space",
    description:
      "I built a modern and stylish hair salon website using React. The website features a sleek design with easy navigation and showcases the salon's services, prices and booking options.",
    getImageSrc: () => photo1,
  },
  {
    title: "React Infinite Scroll",
    description:
      "I built a modern and stylish hair salon website using React. The website features a sleek design with easy navigation and showcases the salon's services, prices and booking options.",
    getImageSrc: () => photo2,
  },
  {
    title: "Photo Gallery",
    description:
      "I built a modern and stylish hair salon website using React. The website features a sleek design with easy navigation and showcases the salon's services, prices and booking options.",
    getImageSrc: () => photo3,
  },
  {
    title: "Event Planner",
    description:
      "I built a modern and stylish hair salon website using React. The website features a sleek design with easy navigation and showcases the salon's services, prices and booking options.",
    getImageSrc: () => photo4,
  },
];
const Projects = () => {
  return (
    <DashboardScreenSection
      backgroundColor="lightgray"
      isDarkBackground
      p={8}
      alignItems="flex-start"
      spacing={8}
    >
      <Heading as="h1" id="projects-section" color="#2A4365">
        Featured Projects
      </Heading>

      <Box
        display="grid"
        gridTemplateColumns="repeat(2,minmax(0,1fr))"
        gridGap={8}
      >
        {projects.map((project) => (
          <Card
            key={project.title}
            title={project.title}
            description={project.description}
            imageSrc={project.getImageSrc()}
          />
        ))}
      </Box>
    </DashboardScreenSection>
  );
};

export default Projects;
